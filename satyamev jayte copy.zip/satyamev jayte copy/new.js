function redirectToResult() {
    window.location.href = "result.html"; // Make sure result.html is in the same directory
}
